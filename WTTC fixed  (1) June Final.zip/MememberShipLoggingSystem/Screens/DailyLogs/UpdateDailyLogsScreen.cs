﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.DailyLogs
{
    public partial class UpdateDailyLogsScreen : TemplateForm
    {
        public UpdateDailyLogsScreen()
        {
            InitializeComponent();
        }
        public int LogId { get; set; }
        public bool IsUpdate { get; set; }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetFormControls();
        }

        private void ResetFormControls()
        {
            
        }

        private void UpdateDailyLogsScreen_Load(object sender, EventArgs e)
        {
            LoadDataIntoComboBox();
            if (IsUpdate == true)
            {
                LoadAndBindData();
            }
        }

        private void LoadAndBindData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_DailyLogsGetLogDetailsForUpdate", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.Parameters.AddWithValue("@LogId", this.LogId);
                        DataTable dtUsers = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtUsers.Load(sdr);
                        DataRow row = dtUsers.Rows[0];
                        MemberNameComboBox.SelectedValue = row["MemberId"];
                        LogDateDateTimePicker.Value = Convert.ToDateTime(row["LogDate"]);
                        MoneyPaidTextBox.Text = row["MoneyPaid"].ToString();
                        OtherDetailsTextBox.Text = row["OtherDetails"].ToString();
                        saveButton.Text = "Update Record";
                        deleteButton.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void LoadDataIntoComboBox()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_MembersLoadMembersIntoComboBox", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    MemberNameComboBox.DataSource = dtRoles;
                    MemberNameComboBox.DisplayMember = "FirstName";
                    MemberNameComboBox.ValueMember = "MemberId";
                    MemberNameComboBox.SelectedIndex = -1;
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (this.IsUpdate)
            {
                UpdateRecord();
                
            }
        }

        private void UpdateRecord()
        {
            //
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_DailyLogsUpdateLog", con))
                    {
                        int memberId = 0;
                        if(MemberNameComboBox.SelectedIndex==-1)
                        {
                            memberId = 0;
                        }
                        else
                        {
                            memberId = Convert.ToInt32(MemberNameComboBox.SelectedValue);
                        }
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@LogId", this.LogId);
                        cmd.Parameters.AddWithValue("@MemberId",memberId);
                        cmd.Parameters.AddWithValue("@LogDate", LogDateDateTimePicker.Value);
                        cmd.Parameters.AddWithValue("@MoneyPaid", MoneyPaidTextBox.Text);
                        cmd.Parameters.AddWithValue("@OtherDetails", OtherDetailsTextBox.Text);
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        Alertify.Success("Daily Log Entry Updated Successfully");
                        ResetFormControls();
                        this.Close();
                    }
                }
            }
        }

        private bool IsFormValid()
        {
            //if(MemberNameComboBox.SelectedIndex==-1)
            //{
            //    Alertify.Error("Member Name is Requried!");
            //    return false;
            //}
            return true;
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteRecord();
        }

        private void DeleteRecord()
        {
            if (this.IsUpdate)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this Log Entry", "Confirm Operation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_DailyLogsDeleteLogEntry", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@LogId", this.LogId);
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Log Entry Deleted Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ResetFormControls();
                            this.Close();

                        }
                    }
                }
            }
        }

        private void MoneyPaidTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }
    }
}
