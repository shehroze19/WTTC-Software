﻿namespace MememberShipLoggingSystem.Screens
{
    partial class DashboardScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.AdminMneu = new System.Windows.Forms.ToolStripMenuItem();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rolesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewRoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewRolesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.manageMembersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMembersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyLogEntriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewLogEntriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.membersReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.labelDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.UserAccessLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.LabelUniqueNonMembers = new System.Windows.Forms.Label();
            this.LabelUniqueMembers = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TotalUserLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.MemberIdTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LogDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.RFIDNoTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.viewHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button3 = new System.Windows.Forms.Button();
            this.ExportToExcelButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.DailyLogAddButton = new System.Windows.Forms.Button();
            this.DailyPayingButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem1,
            this.AdminMneu,
            this.toolStripMenuItem2,
            this.manageMembersToolStripMenuItem,
            this.toolStripMenuItem3,
            this.dailyLogEntriesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(20, 95);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1896, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changePasswordToolStripMenuItem,
            this.logOutToolStripMenuItem,
            this.exitApplicationToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(64, 36);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(295, 36);
            this.changePasswordToolStripMenuItem.Text = "&Change  Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(295, 36);
            this.logOutToolStripMenuItem.Text = "&Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // exitApplicationToolStripMenuItem
            // 
            this.exitApplicationToolStripMenuItem.Name = "exitApplicationToolStripMenuItem";
            this.exitApplicationToolStripMenuItem.Size = new System.Drawing.Size(295, 36);
            this.exitApplicationToolStripMenuItem.Text = "&Exit Application";
            this.exitApplicationToolStripMenuItem.Click += new System.EventHandler(this.exitApplicationToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(33, 36);
            this.toolStripMenuItem1.Text = "|";
            // 
            // AdminMneu
            // 
            this.AdminMneu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usersToolStripMenuItem,
            this.rolesToolStripMenuItem});
            this.AdminMneu.Name = "AdminMneu";
            this.AdminMneu.Size = new System.Drawing.Size(178, 36);
            this.AdminMneu.Text = "&Manage Users";
            this.AdminMneu.Visible = false;
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewUserToolStripMenuItem,
            this.viewUsersToolStripMenuItem});
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(159, 36);
            this.usersToolStripMenuItem.Text = "&Users";
            // 
            // addNewUserToolStripMenuItem
            // 
            this.addNewUserToolStripMenuItem.Name = "addNewUserToolStripMenuItem";
            this.addNewUserToolStripMenuItem.Size = new System.Drawing.Size(254, 36);
            this.addNewUserToolStripMenuItem.Text = "&Add New User";
            this.addNewUserToolStripMenuItem.Click += new System.EventHandler(this.addNewUserToolStripMenuItem_Click);
            // 
            // viewUsersToolStripMenuItem
            // 
            this.viewUsersToolStripMenuItem.Name = "viewUsersToolStripMenuItem";
            this.viewUsersToolStripMenuItem.Size = new System.Drawing.Size(254, 36);
            this.viewUsersToolStripMenuItem.Text = "&View Users";
            this.viewUsersToolStripMenuItem.Click += new System.EventHandler(this.viewUsersToolStripMenuItem_Click);
            // 
            // rolesToolStripMenuItem
            // 
            this.rolesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewRoleToolStripMenuItem,
            this.viewRolesToolStripMenuItem});
            this.rolesToolStripMenuItem.Name = "rolesToolStripMenuItem";
            this.rolesToolStripMenuItem.Size = new System.Drawing.Size(159, 36);
            this.rolesToolStripMenuItem.Text = "&Roles";
            // 
            // addNewRoleToolStripMenuItem
            // 
            this.addNewRoleToolStripMenuItem.Name = "addNewRoleToolStripMenuItem";
            this.addNewRoleToolStripMenuItem.Size = new System.Drawing.Size(253, 36);
            this.addNewRoleToolStripMenuItem.Text = "&Add New Role";
            this.addNewRoleToolStripMenuItem.Click += new System.EventHandler(this.addNewRoleToolStripMenuItem_Click);
            // 
            // viewRolesToolStripMenuItem
            // 
            this.viewRolesToolStripMenuItem.Name = "viewRolesToolStripMenuItem";
            this.viewRolesToolStripMenuItem.Size = new System.Drawing.Size(253, 36);
            this.viewRolesToolStripMenuItem.Text = "&View Roles";
            this.viewRolesToolStripMenuItem.Click += new System.EventHandler(this.viewRolesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(33, 36);
            this.toolStripMenuItem2.Text = "|";
            // 
            // manageMembersToolStripMenuItem
            // 
            this.manageMembersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewMemberToolStripMenuItem,
            this.viewMembersToolStripMenuItem,
            this.viewHistoryToolStripMenuItem});
            this.manageMembersToolStripMenuItem.Name = "manageMembersToolStripMenuItem";
            this.manageMembersToolStripMenuItem.Size = new System.Drawing.Size(222, 36);
            this.manageMembersToolStripMenuItem.Text = "Manage Members";
            // 
            // addNewMemberToolStripMenuItem
            // 
            this.addNewMemberToolStripMenuItem.Name = "addNewMemberToolStripMenuItem";
            this.addNewMemberToolStripMenuItem.Size = new System.Drawing.Size(298, 36);
            this.addNewMemberToolStripMenuItem.Text = "&Add New Member";
            this.addNewMemberToolStripMenuItem.Click += new System.EventHandler(this.addNewMemberToolStripMenuItem_Click);
            // 
            // viewMembersToolStripMenuItem
            // 
            this.viewMembersToolStripMenuItem.Name = "viewMembersToolStripMenuItem";
            this.viewMembersToolStripMenuItem.Size = new System.Drawing.Size(298, 36);
            this.viewMembersToolStripMenuItem.Text = "&View Members";
            this.viewMembersToolStripMenuItem.Click += new System.EventHandler(this.viewMembersToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(33, 36);
            this.toolStripMenuItem3.Text = "|";
            // 
            // dailyLogEntriesToolStripMenuItem
            // 
            this.dailyLogEntriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewLogEntriesToolStripMenuItem,
            this.membersReportsToolStripMenuItem});
            this.dailyLogEntriesToolStripMenuItem.Name = "dailyLogEntriesToolStripMenuItem";
            this.dailyLogEntriesToolStripMenuItem.Size = new System.Drawing.Size(107, 36);
            this.dailyLogEntriesToolStripMenuItem.Text = "Reports";
            // 
            // viewLogEntriesToolStripMenuItem
            // 
            this.viewLogEntriesToolStripMenuItem.Name = "viewLogEntriesToolStripMenuItem";
            this.viewLogEntriesToolStripMenuItem.Size = new System.Drawing.Size(317, 36);
            this.viewLogEntriesToolStripMenuItem.Text = "View  Finance Sheet";
            this.viewLogEntriesToolStripMenuItem.Click += new System.EventHandler(this.viewLogEntriesToolStripMenuItem_Click);
            // 
            // membersReportsToolStripMenuItem
            // 
            this.membersReportsToolStripMenuItem.Name = "membersReportsToolStripMenuItem";
            this.membersReportsToolStripMenuItem.Size = new System.Drawing.Size(317, 36);
            this.membersReportsToolStripMenuItem.Text = "Members Reports";
            this.membersReportsToolStripMenuItem.Click += new System.EventHandler(this.membersReportsToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.labelDate});
            this.statusStrip1.Location = new System.Drawing.Point(20, 975);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(2, 0, 16, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1896, 30);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // labelDate
            // 
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(49, 25);
            this.labelDate.Text = "Date";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(1102, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Welcome:";
            this.label1.Visible = false;
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UserNameLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserNameLabel.Location = new System.Drawing.Point(1222, 21);
            this.UserNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(127, 30);
            this.UserNameLabel.TabIndex = 3;
            this.UserNameLabel.Text = "User Name";
            this.UserNameLabel.Visible = false;
            // 
            // UserAccessLabel
            // 
            this.UserAccessLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.UserAccessLabel.AutoSize = true;
            this.UserAccessLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UserAccessLabel.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserAccessLabel.Location = new System.Drawing.Point(1029, 21);
            this.UserAccessLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UserAccessLabel.Name = "UserAccessLabel";
            this.UserAccessLabel.Size = new System.Drawing.Size(0, 30);
            this.UserAccessLabel.TabIndex = 5;
            this.UserAccessLabel.Visible = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(909, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 30);
            this.label3.TabIndex = 4;
            this.label3.Text = "Access:";
            this.label3.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvUsers);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(20, 135);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1896, 840);
            this.panel1.TabIndex = 6;
            // 
            // dgvUsers
            // 
            this.dgvUsers.AllowUserToAddRows = false;
            this.dgvUsers.AllowUserToDeleteRows = false;
            this.dgvUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUsers.Location = new System.Drawing.Point(0, 143);
            this.dgvUsers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.ReadOnly = true;
            this.dgvUsers.RowHeadersVisible = false;
            this.dgvUsers.RowTemplate.Height = 24;
            this.dgvUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUsers.Size = new System.Drawing.Size(1896, 697);
            this.dgvUsers.TabIndex = 11;
            this.dgvUsers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUsers_CellContentClick);
            this.dgvUsers.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUsers_CellDoubleClick);
            this.dgvUsers.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvUsers_CellFormatting);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.ExportToExcelButton);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.DailyLogAddButton);
            this.panel2.Controls.Add(this.DailyPayingButton);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.MemberIdTextBox);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.LogDateDateTimePicker);
            this.panel2.Controls.Add(this.RFIDNoTextBox);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1896, 143);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.LabelUniqueNonMembers);
            this.panel3.Controls.Add(this.LabelUniqueMembers);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.TotalUserLabel);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(1423, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(473, 143);
            this.panel3.TabIndex = 42;
            // 
            // LabelUniqueNonMembers
            // 
            this.LabelUniqueNonMembers.AutoSize = true;
            this.LabelUniqueNonMembers.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelUniqueNonMembers.ForeColor = System.Drawing.Color.Red;
            this.LabelUniqueNonMembers.Location = new System.Drawing.Point(298, 92);
            this.LabelUniqueNonMembers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LabelUniqueNonMembers.Name = "LabelUniqueNonMembers";
            this.LabelUniqueNonMembers.Size = new System.Drawing.Size(29, 32);
            this.LabelUniqueNonMembers.TabIndex = 48;
            this.LabelUniqueNonMembers.Text = "0";
            // 
            // LabelUniqueMembers
            // 
            this.LabelUniqueMembers.AutoSize = true;
            this.LabelUniqueMembers.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelUniqueMembers.ForeColor = System.Drawing.Color.Red;
            this.LabelUniqueMembers.Location = new System.Drawing.Point(298, 52);
            this.LabelUniqueMembers.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LabelUniqueMembers.Name = "LabelUniqueMembers";
            this.LabelUniqueMembers.Size = new System.Drawing.Size(29, 32);
            this.LabelUniqueMembers.TabIndex = 47;
            this.LabelUniqueMembers.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 92);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(270, 32);
            this.label7.TabIndex = 46;
            this.label7.Text = "Unique Non-Members";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(21, 55);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(211, 32);
            this.label6.TabIndex = 45;
            this.label6.Text = "Unique Members";
            // 
            // TotalUserLabel
            // 
            this.TotalUserLabel.AutoSize = true;
            this.TotalUserLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalUserLabel.ForeColor = System.Drawing.Color.Red;
            this.TotalUserLabel.Location = new System.Drawing.Point(298, 12);
            this.TotalUserLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TotalUserLabel.Name = "TotalUserLabel";
            this.TotalUserLabel.Size = new System.Drawing.Size(29, 32);
            this.TotalUserLabel.TabIndex = 44;
            this.TotalUserLabel.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 14);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 32);
            this.label5.TabIndex = 43;
            this.label5.Text = "Total Logs";
            // 
            // MemberIdTextBox
            // 
            this.MemberIdTextBox.Location = new System.Drawing.Point(214, 49);
            this.MemberIdTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MemberIdTextBox.Name = "MemberIdTextBox";
            this.MemberIdTextBox.Size = new System.Drawing.Size(175, 36);
            this.MemberIdTextBox.TabIndex = 40;
            this.MemberIdTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MemberIdTextBox_KeyDown);
            this.MemberIdTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemberIdTextBox_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(210, 16);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 30);
            this.label4.TabIndex = 41;
            this.label4.Text = "Enter Member ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(412, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 30);
            this.label2.TabIndex = 39;
            this.label2.Text = "Log Date";
            // 
            // LogDateDateTimePicker
            // 
            this.LogDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.LogDateDateTimePicker.Location = new System.Drawing.Point(412, 51);
            this.LogDateDateTimePicker.Name = "LogDateDateTimePicker";
            this.LogDateDateTimePicker.Size = new System.Drawing.Size(157, 36);
            this.LogDateDateTimePicker.TabIndex = 38;
            this.LogDateDateTimePicker.ValueChanged += new System.EventHandler(this.LogDateDateTimePicker_ValueChanged);
            // 
            // RFIDNoTextBox
            // 
            this.RFIDNoTextBox.Location = new System.Drawing.Point(10, 49);
            this.RFIDNoTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RFIDNoTextBox.Name = "RFIDNoTextBox";
            this.RFIDNoTextBox.Size = new System.Drawing.Size(190, 36);
            this.RFIDNoTextBox.TabIndex = 36;
            this.RFIDNoTextBox.TextChanged += new System.EventHandler(this.RFIDNoTextBox_TextChanged);
            this.RFIDNoTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RFIDNoTextBox_KeyDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 16);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(195, 30);
            this.label10.TabIndex = 37;
            this.label10.Text = "Scan RFID Number";
            // 
            // viewHistoryToolStripMenuItem
            // 
            this.viewHistoryToolStripMenuItem.Name = "viewHistoryToolStripMenuItem";
            this.viewHistoryToolStripMenuItem.Size = new System.Drawing.Size(298, 36);
            this.viewHistoryToolStripMenuItem.Text = "View History";
            this.viewHistoryToolStripMenuItem.Click += new System.EventHandler(this.viewHistoryToolStripMenuItem_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SeaShell;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = global::MememberShipLoggingSystem.Properties.Resources.run_rebuild_2;
            this.button3.Location = new System.Drawing.Point(1116, 74);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(219, 56);
            this.button3.TabIndex = 48;
            this.button3.Text = "Refresh  Screen";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // ExportToExcelButton
            // 
            this.ExportToExcelButton.BackColor = System.Drawing.Color.SeaShell;
            this.ExportToExcelButton.FlatAppearance.BorderSize = 2;
            this.ExportToExcelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExportToExcelButton.Image = global::MememberShipLoggingSystem.Properties.Resources.document_export;
            this.ExportToExcelButton.Location = new System.Drawing.Point(1116, 6);
            this.ExportToExcelButton.Name = "ExportToExcelButton";
            this.ExportToExcelButton.Size = new System.Drawing.Size(219, 63);
            this.ExportToExcelButton.TabIndex = 47;
            this.ExportToExcelButton.Text = "Export to Excel";
            this.ExportToExcelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ExportToExcelButton.UseVisualStyleBackColor = false;
            this.ExportToExcelButton.Click += new System.EventHandler(this.ExportToExcel_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SeaShell;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = global::MememberShipLoggingSystem.Properties.Resources.emblem_advertisement_dollar;
            this.button2.Location = new System.Drawing.Point(585, 74);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(188, 56);
            this.button2.TabIndex = 46;
            this.button2.Text = "Custom";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SeaShell;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::MememberShipLoggingSystem.Properties.Resources.user_new_2;
            this.button1.Location = new System.Drawing.Point(791, 75);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(305, 53);
            this.button1.TabIndex = 45;
            this.button1.Text = "Daily Log For Adult";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DailyLogAddButton
            // 
            this.DailyLogAddButton.BackColor = System.Drawing.Color.SeaShell;
            this.DailyLogAddButton.FlatAppearance.BorderSize = 2;
            this.DailyLogAddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DailyLogAddButton.Image = global::MememberShipLoggingSystem.Properties.Resources.user_new;
            this.DailyLogAddButton.Location = new System.Drawing.Point(791, 10);
            this.DailyLogAddButton.Name = "DailyLogAddButton";
            this.DailyLogAddButton.Size = new System.Drawing.Size(306, 59);
            this.DailyLogAddButton.TabIndex = 44;
            this.DailyLogAddButton.Text = "Daily Log For Young";
            this.DailyLogAddButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.DailyLogAddButton.UseVisualStyleBackColor = false;
            this.DailyLogAddButton.Click += new System.EventHandler(this.DailyLogAddButton_Click);
            // 
            // DailyPayingButton
            // 
            this.DailyPayingButton.BackColor = System.Drawing.Color.SeaShell;
            this.DailyPayingButton.FlatAppearance.BorderSize = 2;
            this.DailyPayingButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DailyPayingButton.Image = global::MememberShipLoggingSystem.Properties.Resources.document_open_2;
            this.DailyPayingButton.Location = new System.Drawing.Point(585, 10);
            this.DailyPayingButton.Name = "DailyPayingButton";
            this.DailyPayingButton.Size = new System.Drawing.Size(188, 59);
            this.DailyPayingButton.TabIndex = 43;
            this.DailyPayingButton.Text = "Load All Logs";
            this.DailyPayingButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.DailyPayingButton.UseVisualStyleBackColor = false;
            this.DailyPayingButton.Click += new System.EventHandler(this.DailyPayingButton_Click);
            // 
            // DashboardScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1936, 1026);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.UserAccessLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.UserNameLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "DashboardScreen";
            this.Padding = new System.Windows.Forms.Padding(20, 95, 20, 21);
            this.ShowInTaskbar = true;
            this.Text = "Dashboard Screen";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.DashboardScreen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitApplicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem AdminMneu;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rolesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewRoleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewRolesToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel labelDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.Label UserAccessLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem manageMembersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewMembersToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.TextBox RFIDNoTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker LogDateDateTimePicker;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label TotalUserLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button DailyPayingButton;
        private System.Windows.Forms.ToolStripMenuItem dailyLogEntriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewLogEntriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membersReportsToolStripMenuItem;
        private System.Windows.Forms.Button DailyLogAddButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button ExportToExcelButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label LabelUniqueNonMembers;
        private System.Windows.Forms.Label LabelUniqueMembers;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox MemberIdTextBox;
        private System.Windows.Forms.ToolStripMenuItem viewHistoryToolStripMenuItem;
    }
}