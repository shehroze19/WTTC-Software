﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Users
{
    public partial class ViewRolesScreen : TemplateForm
    {
        public ViewRolesScreen()
        {
            InitializeComponent();
            LoadDataIntoGridView();
        }

        private void LoadDataIntoGridView()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_RolesLoadDataIntoGridView", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    dgvRoles.DataSource = dtRoles;
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddRolesScreen addrole = new AddRolesScreen();
            addrole.ShowDialog();
            LoadDataIntoGridView();
        }

        private void refreshScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
            txtSearch.Clear();
        }

        private void dgvRoles_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvRoles.Rows.Count > 0)
            {
                int RoleID = Convert.ToInt32(dgvRoles.SelectedRows[0].Cells[0].Value);
                AddRolesScreen addroll = new AddRolesScreen();
                addroll.RoleId = RoleID;
                addroll.IsUpdate = true;
                addroll.ShowDialog();
                LoadDataIntoGridView();
            }
        }

        private void ViewRolesScreen_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (btnSearch.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_RolesSearchByTitle", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RoleTitle", txtSearch.Text.Trim());
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        DataTable dtRole = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            dtRole.Load(sdr);
                            dgvRoles.DataSource = dtRole;
                        }
                        else
                        {
                            MessageBox.Show("No Records Were Found", "No Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                }
            }
        }
    }
}
