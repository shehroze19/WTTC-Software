﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Users
{
    public partial class AddRolesScreen : TemplateForm
    {
        public AddRolesScreen()
        {
            InitializeComponent();
        }
        // properties to handle update process
        public int RoleId { get; set; }
        public bool IsUpdate { get; set; }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(AppConnection.GetConnectionString());
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.IsUpdate)
            {
                UpdateRecord();
            }
            else
            {
                SaveRecord();
            }

        }

        private void UpdateRecord()
        {
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_RolesUpdateRoleByRoleId", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RoleId", RoleId);
                        cmd.Parameters.AddWithValue("@RoleTitle", txtRoleTitle.Text);
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Role Updated Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ResetFormControls();
                    }
                }
            }
        }

        private void SaveRecord()
        {
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_RolesAddNewRole", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RoleTitle", txtRoleTitle.Text);
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Role Added Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ResetFormControls();
                    }
                }
            }
        }

        private void ResetFormControls()
        {
            txtRoleTitle.Clear();
            txtDescription.Clear();
            if (this.IsUpdate)
            {
                this.RoleId = 0;
                this.IsUpdate = false;
                saveButton.Text = "Save Record";
                deleteButton.Enabled = false;
            }
        }

        private bool IsFormValid()
        {
            if (txtRoleTitle.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Role Title is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRoleTitle.Focus();
                return false;
            }
            if (txtDescription.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Description is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return false;
            }
            return true;
        }

        private void AddRolesScreen_Load(object sender, EventArgs e)
        {
            if (IsUpdate == true)
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_RolesGetDataForUpdate", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.Parameters.AddWithValue("@RoleId", RoleId);
                        DataTable dtRoles = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtRoles.Load(sdr);
                        DataRow row = dtRoles.Rows[0];
                        txtRoleTitle.Text = row["RoleTitle"].ToString();
                        txtDescription.Text = row["Description"].ToString();
                        saveButton.Text = "Update Record";
                        deleteButton.Enabled = true;
                    }
                }
            }

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (this.IsUpdate)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this Role", "Confirm Operation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_RolesDeleteRoleByRoleId", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@RoleId", this.RoleId);
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Role Deleted Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ResetFormControls();

                        }
                    }
                }
            }
        }
    }
}
