﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Users
{
    public partial class ViewUsersScreen : TemplateForm
    {
        public ViewUsersScreen()
        {
            InitializeComponent();
            LoadDataIntoDataGridView();
        }

        private void LoadDataIntoDataGridView()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_UserLoadDataIntoDataGridView", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    dgvUsers.DataSource = dtRoles;
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewUserScreen user = new AddNewUserScreen();
            user.ShowDialog();
            LoadDataIntoDataGridView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (btnSearch.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_UserSearchByUserNameOrRole", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Filter", txtSearch.Text.Trim());
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        DataTable dtRole = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            dtRole.Load(sdr);
                            dgvUsers.DataSource = dtRole;
                        }
                        else
                        {
                            MessageBox.Show("No Records Were Found", "No Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                }
            }
        }

        private void refreshScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadDataIntoDataGridView();

        }

        private void dgvUsers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvUsers.Rows.Count > 0)
            {
                // int UserID = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells[0].Value);
                // AddNewUserScreen adduser = new AddNewUserScreen();
                //// adduser.RoleId = UserID;
                // adduser.IsUpdate = true;
                // adduser.ShowDialog();
                // LoadDataIntoDataGridView();
                string username = dgvUsers.SelectedRows[0].Cells[0].Value.ToString();
                AddNewUserScreen userform = new AddNewUserScreen();
                userform.UserName = username;
                userform.IsUpdate = true;
                userform.ShowDialog();
                LoadDataIntoDataGridView();
            }
        }

        private void ViewUsersScreen_Load(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
