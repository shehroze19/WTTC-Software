﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.DailyLogs;
using MememberShipLoggingSystem.Screens.Memembers;
using MememberShipLoggingSystem.Screens.ReportsScreen;
using MememberShipLoggingSystem.Screens.Template;
using MememberShipLoggingSystem.Screens.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens
{
    public partial class DashboardScreen : TemplateForm
    {
        public DashboardScreen()
        {
            InitializeComponent();
        }
        string FileLocation = "";
        private void addNewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewUserScreen newuser = new AddNewUserScreen();
            newuser.ShowDialog();
        }

        private void viewUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewUsersScreen viewuser = new ViewUsersScreen();
            viewuser.ShowDialog();
        }

        private void addNewRoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddRolesScreen addrole = new AddRolesScreen();
            addrole.ShowDialog();
        }

        private void viewRolesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewRolesScreen viewroles = new ViewRolesScreen();
            viewroles.ShowDialog();
        }

        private void exitApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DashboardScreen_Load(object sender, EventArgs e)
        {
            labelDate.Text = DateTime.Today.ToString();
            UserNameLabel.Text = LoggedInUser.UserName;

            SetupUserAccess();
            LoadDataIntoGrdiView();
        }

        private void SetupUserAccess()
        {
            switch (LoggedInUser.RoleId)
            {
                case 1:
                    UserAccessLabel.Text = "Full Rights";
                    AdminMneu.Visible = true;
                    break;
                case 2:
                    UserAccessLabel.Text = "Normal Rights";
                    break;
                case 3:
                    UserAccessLabel.Text = "Limted Rights";
                    break;
                default:
                    break;
            }
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePasswordScreen cps = new ChangePasswordScreen();
            cps.ShowDialog();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void addNewMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewMemeberScreen addnew = new AddNewMemeberScreen();
            addnew.Show();
        }

        private void viewMembersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewMemberScreen view = new ViewMemberScreen();
            view.ShowDialog();
        }

        private void RFIDNoTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {

                    if (RFIDNoTextBox.Text.Trim() != string.Empty)
                    {
                        using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                        {
                            using (SqlCommand cmd = new SqlCommand("usp_MembersLoadByRFID", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                if (con.State != ConnectionState.Open)
                                    con.Open();
                                cmd.Parameters.AddWithValue("@RFIDNumber",RFIDNoTextBox.Text.Trim());
                                DataTable dtMember = new DataTable();
                                SqlDataReader sdr = cmd.ExecuteReader();
                                dtMember.Load(sdr);
                                if (dtMember.Rows.Count > 0)
                                {
                                    DataRow row = dtMember.Rows[0];
                                    if(row["type"].ToString()== "Parkinson")
                                    {
                                        using (SqlCommand cmd3 = new SqlCommand("Select Swipes From PPP Where MemberId = @MemberId ", con))
                                        {
                                            if (con.State != ConnectionState.Open)
                                                con.Open();
                                            cmd3.CommandType = CommandType.Text;
                                            cmd3.Parameters.AddWithValue("@MemberId", Convert.ToInt32(row["MemberId"]));
                                            DataTable dtSwipes = new DataTable();
                                            SqlDataReader sdr2 = cmd3.ExecuteReader();
                                            dtSwipes.Load(sdr2);
                                            if(dtSwipes.Rows.Count > 0)
                                            {
                                                DataRow row2 = dtSwipes.Rows[0];
                                                if(Convert.ToInt32(row2["Swipes"])<=0)
                                                {
                                                    //MessageBox.Show(""+ Convert.ToInt32(row2["Swipes"]));
                                                    SoundPlayer snd = new SoundPlayer(Properties.Resources.error);
                                                    snd.Play();
                                                    
                                                }
                                                else
                                                {
                                                    using (SqlCommand cmd4 = new SqlCommand("update PPP Set Swipes = Swipes - 1 Where MemberId = @MemberId", con))
                                                    {
                                                        cmd4.CommandType = CommandType.Text;
                                                        cmd4.Parameters.AddWithValue("@MemberId", Convert.ToInt32(row["MemberId"]));
                                                 
                                                        if (con.State != ConnectionState.Open)
                                                            con.Open();
                                                        cmd4.ExecuteNonQuery();
                                                        
                                                    }
                                                }
                                            }

                                        }
                                     }
                                    using (SqlCommand cmd2 = new SqlCommand("usp_DailyLogsAddNewLog", con))
                                    {
                                        cmd2.CommandType = CommandType.StoredProcedure;
                                        cmd2.Parameters.AddWithValue("@MemberId", Convert.ToInt32(row["MemberId"]));
                                        cmd2.Parameters.AddWithValue("@LogDate", DateTime.Now);
                                        cmd2.Parameters.AddWithValue("@LogTime", DateTime.Now.ToString("h:mm:ss tt"));
                                        cmd2.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                                        if (con.State != ConnectionState.Open)
                                            con.Open();
                                        cmd2.ExecuteNonQuery();
                                        ResetFormControls();
                                        LoadDataIntoGrdiView();
                                    }

                                }
                                else
                                {
                                    MessageBox.Show("Member Not Found");
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Alertify.Error(ex.Message);
               
            }
        }

        private void LoadDataIntoGrdiView()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_DailyLogsLoadIntoGridView", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@LogDate", LogDateDateTimePicker.Value);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        DataTable dtRoles = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtRoles.Load(sdr);
                        dgvUsers.DataSource = dtRoles;
                        CountUsers();
                        CountUniqueUsers();
                        if(dgvUsers.Rows.Count> 0)
                        {
                            // check if expired then play sound 
                            if (dgvUsers.Rows[0].Cells["MembershipStatus"].Value.ToString() == "Expired Members")
                            {
                                SoundPlayer snd = new SoundPlayer(Properties.Resources.error);
                                snd.Play();

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void CountUniqueUsers()
        {
            int members = dgvUsers.Rows
            .Cast<DataGridViewRow>()
            .Select(r => (int)r.Cells["MemberId"].Value)
            .Distinct()
            .Count();
            
            LabelUniqueMembers.Text = members.ToString();
         }

        private void MakeCellsGreenAndRed()
        {
            if (dgvUsers.Rows.Count > 0)
            {
                
                foreach (DataGridViewRow row in dgvUsers.Rows)
                {
                    if(dgvUsers.CurrentRow.Cells["MembershipStatus"].ToString()== "Expired Members")
                    {
                        MessageBox.Show("Test");
                    }
                           
                }
                
            }
        }

        private void CountUsers()
        {
            if(dgvUsers.Rows.Count>0)
            {
                int nonMembersCount = 0;
            
                int count = 0;
                foreach (DataGridViewRow row in dgvUsers.Rows)
                {
                    if(Convert.ToInt32(row.Cells[1].Value)==0)
                    {
                        nonMembersCount++;
                    }
                   
                    count++;
                }
                TotalUserLabel.Text = count.ToString();
                LabelUniqueNonMembers.Text = nonMembersCount.ToString();
            }
        }

        private void ResetFormControls()
        {
            RFIDNoTextBox.Clear();
        }

        private void RFIDNoTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgvUsers_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //Int32 MemberShipStatusColumn = 7;
            //Int32 TuesdayLeagueNight = 10;
            //Int32 ThursdayLeagueNight = 11;

            try
            {
                DataGridViewCell cell = dgvUsers.Rows[e.RowIndex].Cells["MembershipStatus"];
                DataGridViewCell cell2 = dgvUsers.Rows[e.RowIndex].Cells["TuesdayLeagueNightMembership"];
                DataGridViewCell cell3 = dgvUsers.Rows[e.RowIndex].Cells["ThursdayLeagueNightMembership"];
                DataGridViewCell cell4 = dgvUsers.Rows[e.RowIndex].Cells["MemembershipExpiryDate"];
                String value = cell.Value == null ? string.Empty : cell.Value.ToString();


                if (!DBNull.Value.Equals(cell.Value) && !DBNull.Value.Equals(cell2.Value) && !DBNull.Value.Equals(cell3.Value) && !DBNull.Value.Equals(cell4.Value))
                {
                    if (value.Equals("Expired Members") == true)
                    {
                        cell.Style.BackColor = Color.Red;
                        
                    }

                    else
                    {
                        cell.Style.BackColor = Color.Green;

                    }
                    if (Convert.ToInt32(cell2.Value) < 30 )
                    {
                        cell2.Style.BackColor = Color.Red;
                    }
                    else
                    {
                        cell2.Style.BackColor = Color.Green;

                    }
                    if (Convert.ToInt32(cell3.Value) < 30 )
                    {
                        cell3.Style.BackColor = Color.Red;
                    }
                    else
                    {
                        cell3.Style.BackColor = Color.Green;
                    }
                    if (Convert.ToDateTime(cell4.Value) < DateTime.Now)
                    {
                        cell4.Style.BackColor = Color.Red;
                    }
                    else
                    {
                        cell4.Style.BackColor = Color.Green;
                    }
                }

            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void dgvUsers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvUsers.Rows.Count>0)
            {
                try
                {
                    int logid = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells[0].Value);
                    UpdateDailyLogsScreen addnew = new UpdateDailyLogsScreen();
                    addnew.LogId = logid;
                    addnew.IsUpdate = true;
                    addnew.ShowDialog();
                    LoadDataIntoGrdiView();
                }
                catch (Exception ex)
                {

                    Alertify.Error(ex.Message);
                }
            }
        }

        private void LogDateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            LoadDataIntoGrdiView();
        }

        private void MemberIdTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {

                    if (MemberIdTextBox.Text.Trim() != string.Empty)
                    {
                        using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                        {
                            using (SqlCommand cmd = new SqlCommand("usp_MembersLoadByMemberID", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                if (con.State != ConnectionState.Open)
                                    con.Open();
                                cmd.Parameters.AddWithValue("@MemberId", MemberIdTextBox.Text.Trim());
                                DataTable dtMember = new DataTable();
                                SqlDataReader sdr = cmd.ExecuteReader();
                                dtMember.Load(sdr);
                                if (dtMember.Rows.Count > 0)
                                {

                                    DataRow row = dtMember.Rows[0];
                                    if (row["type"].ToString() == "Parkinson")
                                    {
                                        using (SqlCommand cmd3 = new SqlCommand("Select Swipes From PPP Where MemberId = @MemberId ", con))
                                        {
                                            if (con.State != ConnectionState.Open)
                                                con.Open();
                                            cmd3.CommandType = CommandType.Text;
                                            cmd3.Parameters.AddWithValue("@MemberId", Convert.ToInt32(row["MemberId"]));
                                            DataTable dtSwipes = new DataTable();
                                            SqlDataReader sdr2 = cmd3.ExecuteReader();
                                            dtSwipes.Load(sdr2);
                                            if (dtSwipes.Rows.Count > 0)
                                            {
                                                DataRow row2 = dtSwipes.Rows[0];
                                                if (Convert.ToInt32(row2["Swipes"]) <= 0)
                                                {
                                                    //MessageBox.Show(""+ Convert.ToInt32(row2["Swipes"]));
                                                    SoundPlayer snd = new SoundPlayer(Properties.Resources.error);
                                                    snd.Play();

                                                }
                                                else
                                                {
                                                    using (SqlCommand cmd4 = new SqlCommand("update PPP Set Swipes = Swipes - 1 Where MemberId = @MemberId", con))
                                                    {
                                                        cmd4.CommandType = CommandType.Text;
                                                        cmd4.Parameters.AddWithValue("@MemberId", Convert.ToInt32(row["MemberId"]));

                                                        if (con.State != ConnectionState.Open)
                                                            con.Open();
                                                        cmd4.ExecuteNonQuery();

                                                    }
                                                }
                                            }

                                        }
                                    }
                                    using (SqlCommand cmd2 = new SqlCommand("usp_DailyLogsAddNewLog", con))
                                    {
                                        cmd2.CommandType = CommandType.StoredProcedure;
                                        cmd2.Parameters.AddWithValue("@MemberId", Convert.ToInt32(row["MemberId"]));
                                        cmd2.Parameters.AddWithValue("@LogDate", DateTime.Now);
                                        cmd2.Parameters.AddWithValue("@LogTime", DateTime.Now.ToString("h:mm:ss tt"));
                                        cmd2.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                                        if (con.State != ConnectionState.Open)
                                            con.Open();
                                        cmd2.ExecuteNonQuery();
                                        ResetFormControls();
                                        LoadDataIntoGrdiView();
                                    }

                                }
                                else
                                {
                                    MessageBox.Show("Member Not Found");
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Alertify.Error(ex.Message);

            }
        }

        private void MemberIdTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void DailyPayingButton_Click(object sender, EventArgs e)
        {
            LoadAllLogs();
        }

        private void LoadAllLogs()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_DailyLogsLoadIntoGridViewAllTime", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        DataTable dtRoles = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtRoles.Load(sdr);
                        dgvUsers.DataSource = dtRoles;
                        CountUsers();
                        CountUniqueUsers();

                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void membersReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MembersReportScreen report = new MembersReportScreen();
            report.ShowDialog();
        }

        private void DailyLogAddButton_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("DailyLogsAddDailyLog", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MemberId", 0);
                        cmd.Parameters.AddWithValue("@LogDate", DateTime.Now);
                        cmd.Parameters.AddWithValue("@LogTime", DateTime.Now.ToString("h:mm:ss tt"));
                        cmd.Parameters.AddWithValue("@MoneyPaid", 10);
                        cmd.Parameters.AddWithValue("@OtherDetails", "");
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        LoadDataIntoGrdiView();
                        Alertify.Success("Daily Log Added for Young!");
                      }
                }

            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("DailyLogsAddDailyLog", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MemberId", 0);
                        cmd.Parameters.AddWithValue("@LogDate", DateTime.Now);
                        cmd.Parameters.AddWithValue("@LogTime", DateTime.Now.ToString("h:mm:ss tt"));
                        cmd.Parameters.AddWithValue("@MoneyPaid", 12);
                        cmd.Parameters.AddWithValue("@OtherDetails", "");
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        LoadDataIntoGrdiView();
                        Alertify.Success("Daily Log Added for Adult!");
                    }
                }

            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void viewLogEntriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DailyLogsReportScreen report = new DailyLogsReportScreen();
            report.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CustomDailyLog custom = new CustomDailyLog();
            custom.ShowDialog();
            LoadDataIntoGrdiView();
        }

        private void ExportToExcel_Click(object sender, EventArgs e)
        {
            if(dgvUsers.Rows.Count>0)
            {
                ExportToExcel();
            }
        }

        private void ExportToExcel()
        {
            try
            {
                // creating Excel Application  
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                // creating new WorkBook within Excel application  
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                // creating new Excelsheet in workbook  
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                // see the excel sheet behind the program  
                app.Visible = true;
                // get the reference of first sheet. By default its name is Sheet1.  
                // store its reference to worksheet  
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                // changing the name of active sheet  
                worksheet.Name = "LogDetails";
                // storing header part in Excel  
                for (int i = 1; i < dgvUsers.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = dgvUsers.Columns[i - 1].HeaderText;
                }
                // storing Each row and column value to excel sheet  
                for (int i = 0; i < dgvUsers.Rows.Count; i++)
                {
                    for (int j = 0; j < dgvUsers.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dgvUsers.Rows[i].Cells[j].Value.ToString();
                    }
                }
                // save the application  
                String FilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFo‌​lder.Desktop),"Log Details " + DateTime.Now.ToString("dd-MM-yyyy HH mm") + ".xlsx");
                workbook.SaveAs(FilePath , Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                
                MessageBox.Show("Log Details Exported Successfully the File is Saved on desktop with name "+ "Log Details " + DateTime.Now.ToString("dd-MM-yyyy HH mm") + ".xlsx", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }

        }

        private void dgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LogDateDateTimePicker.Value = DateTime.Now;
            LoadDataIntoGrdiView();
        }

        private void viewHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewHistoryScreen history = new ViewHistoryScreen();
            history.ShowDialog();
        }
    }
}
