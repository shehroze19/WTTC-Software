﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.DailyLogs
{
    public partial class CustomDailyLog : TemplateForm
    {
        public CustomDailyLog()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void TypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (TypeComboBox.SelectedIndex != -1)
                {
                    if (TypeComboBox.Text == "Adult")
                    {
                        PerformCalculation(12);
                        MoneyPaidTextBox.ReadOnly = true;
                    }
                    if (TypeComboBox.Text == "Young")
                    {
                        PerformCalculation(10);
                        MoneyPaidTextBox.ReadOnly = true;
                    }
                    if (TypeComboBox.Text == "Custom")
                    {
                        MoneyPaidTextBox.ReadOnly = false;
                        MoneyPaidTextBox.Text = "0";
                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void PerformCalculation(decimal rate)
        {
            int NumberOfPeople = Convert.ToInt32(NumberOfPeopleTextBox.Text.Trim());
            decimal totalAmount = NumberOfPeople * rate;
            MoneyPaidTextBox.Text = totalAmount.ToString();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsFormValid())
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("DailyLogsAddDailyLog", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@MemberId", 0);
                            cmd.Parameters.AddWithValue("@LogDate", DateTime.Now);
                            cmd.Parameters.AddWithValue("@LogTime", DateTime.Now.ToString("h:mm:ss tt"));
                            cmd.Parameters.AddWithValue("@MoneyPaid", MoneyPaidTextBox.Text);
                            cmd.Parameters.AddWithValue("@OtherDetails", NumberOfPeopleTextBox.Text);
                            cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            Alertify.Success("Custom Daily Log Entry Added!");
                            this.Close();
                        }
                    }

                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private bool IsFormValid()
        {
            if (TypeComboBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please Select Type!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TypeComboBox.Focus();
                return false;
            }
            if (NumberOfPeopleTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("No of People is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                NumberOfPeopleTextBox.Focus();
                return false;
            }
            if (MoneyPaidTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Money Paid Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MoneyPaidTextBox.Focus();
                return false;
            }
            return true;
        }
    }
}
