﻿using CrystalDecisions.CrystalReports.Engine;
using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.ReportsScreen
{
    public partial class DailyLogsReportScreen : TemplateForm
    {
        public DailyLogsReportScreen()
        {
            InitializeComponent();
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtReportData = new DataTable();
                string r;
                dtReportData = DB.GetDataList("usp_DailyLogsReport", new List<SqlParameter> {
                    new SqlParameter { ParameterName = "@StartDate",Value=StartDateDateTimePicker.Value}, new SqlParameter { ParameterName = "@EndDate",Value=EndDateDateTimePicker.Value } });
                r = @"Reports\DailyLogsReport.rpt";
                ShowReport(r, dtReportData);
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void ShowReport(string _reportName, DataTable dt)
        {
            try
            {
                string reportName = _reportName;
                ReportDocument rDoc = new ReportDocument();
                rDoc.Load(reportName);
                rDoc.SetDataSource(dt);
                crystalReportViewer1.ReportSource = rDoc;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }
    }
}
