﻿using CrystalDecisions.CrystalReports.Engine;
using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.ReportsScreen
{
    public partial class MembersReportScreen : TemplateForm
    {
        public MembersReportScreen()
        {
            InitializeComponent();
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                DataTable dtReportData = new DataTable();
                string r;
                dtReportData = DB.GetDataList("usp_Reports_GetAllActiveMembers");
                r = @"Reports\ActiveMembersReport.rpt";
                ShowReport(r, dtReportData);
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void ShowReport(string _reportName, DataTable dt)
        {
            try
            {
                string reportName = _reportName;
                ReportDocument rDoc = new ReportDocument();
                rDoc.Load(reportName);
                rDoc.SetDataSource(dt);
                crystalReportViewer1.ReportSource = rDoc;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }
    }
}
