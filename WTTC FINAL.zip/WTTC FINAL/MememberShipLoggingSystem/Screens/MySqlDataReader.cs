﻿namespace MememberShipLoggingSystem.Screens
{
    internal class MySqlDataReader
    {
    }
}