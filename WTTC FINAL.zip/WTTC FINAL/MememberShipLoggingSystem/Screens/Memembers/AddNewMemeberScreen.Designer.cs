﻿namespace MememberShipLoggingSystem.Screens.Memembers
{
    partial class AddNewMemeberScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveButton = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteButton = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.MembershipTypeComboBox = new System.Windows.Forms.ComboBox();
            this.LastNameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FirstNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MoneyPaidTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MembershipDateDatetTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ExpiryDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.LockerTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.OtherDetailsTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.CategoryComboBox = new System.Windows.Forms.ComboBox();
            this.RFIDNoTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.TLNMTextBox = new System.Windows.Forms.TextBox();
            this.THLNMTextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.MembershipStatusComboBox = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveButton,
            this.toolStripMenuItem2,
            this.deleteButton,
            this.toolStripMenuItem3,
            this.resetToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(27, 80);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1230, 33);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(67, 29);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(28, 29);
            this.toolStripMenuItem1.Text = "|";
            // 
            // saveButton
            // 
            this.saveButton.Name = "saveButton";
            this.saveButton.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveButton.Size = new System.Drawing.Size(121, 29);
            this.saveButton.Text = "&Save Record";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(28, 29);
            this.toolStripMenuItem2.Text = "|";
            // 
            // deleteButton
            // 
            this.deleteButton.Enabled = false;
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.deleteButton.Size = new System.Drawing.Size(74, 29);
            this.deleteButton.Text = "&Delete";
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(28, 29);
            this.toolStripMenuItem3.Text = "|";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(66, 29);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 317);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 30);
            this.label3.TabIndex = 18;
            this.label3.Text = "Membership Type";
            // 
            // MembershipTypeComboBox
            // 
            this.MembershipTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MembershipTypeComboBox.FormattingEnabled = true;
            this.MembershipTypeComboBox.Location = new System.Drawing.Point(231, 312);
            this.MembershipTypeComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.MembershipTypeComboBox.Name = "MembershipTypeComboBox";
            this.MembershipTypeComboBox.Size = new System.Drawing.Size(389, 38);
            this.MembershipTypeComboBox.TabIndex = 3;
            // 
            // LastNameTextBox
            // 
            this.LastNameTextBox.Location = new System.Drawing.Point(231, 207);
            this.LastNameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.LastNameTextBox.Name = "LastNameTextBox";
            this.LastNameTextBox.Size = new System.Drawing.Size(393, 36);
            this.LastNameTextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 213);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 30);
            this.label2.TabIndex = 15;
            this.label2.Text = "Last Name:";
            // 
            // FirstNameTextBox
            // 
            this.FirstNameTextBox.Location = new System.Drawing.Point(231, 152);
            this.FirstNameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.FirstNameTextBox.Name = "FirstNameTextBox";
            this.FirstNameTextBox.Size = new System.Drawing.Size(393, 36);
            this.FirstNameTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 158);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 30);
            this.label1.TabIndex = 13;
            this.label1.Text = "First Name:";
            // 
            // MoneyPaidTextBox
            // 
            this.MoneyPaidTextBox.Location = new System.Drawing.Point(231, 258);
            this.MoneyPaidTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MoneyPaidTextBox.Name = "MoneyPaidTextBox";
            this.MoneyPaidTextBox.Size = new System.Drawing.Size(393, 36);
            this.MoneyPaidTextBox.TabIndex = 2;
            this.MoneyPaidTextBox.Text = "0";
            this.MoneyPaidTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.THLNMTextBox_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 264);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 30);
            this.label5.TabIndex = 22;
            this.label5.Text = "Money Paid";
            // 
            // MembershipDateDatetTimePicker
            // 
            this.MembershipDateDatetTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.MembershipDateDatetTimePicker.Location = new System.Drawing.Point(231, 370);
            this.MembershipDateDatetTimePicker.Name = "MembershipDateDatetTimePicker";
            this.MembershipDateDatetTimePicker.Size = new System.Drawing.Size(389, 36);
            this.MembershipDateDatetTimePicker.TabIndex = 4;
            this.MembershipDateDatetTimePicker.ValueChanged += new System.EventHandler(this.MembershipDateDatetTimePicker_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 370);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 30);
            this.label6.TabIndex = 25;
            this.label6.Text = "Membership Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 428);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 30);
            this.label4.TabIndex = 27;
            this.label4.Text = "Expiry Date";
            // 
            // ExpiryDateDateTimePicker
            // 
            this.ExpiryDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ExpiryDateDateTimePicker.Location = new System.Drawing.Point(231, 428);
            this.ExpiryDateDateTimePicker.Name = "ExpiryDateDateTimePicker";
            this.ExpiryDateDateTimePicker.Size = new System.Drawing.Size(389, 36);
            this.ExpiryDateDateTimePicker.TabIndex = 5;
            // 
            // LockerTextBox
            // 
            this.LockerTextBox.Location = new System.Drawing.Point(227, 481);
            this.LockerTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.LockerTextBox.Name = "LockerTextBox";
            this.LockerTextBox.Size = new System.Drawing.Size(393, 36);
            this.LockerTextBox.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 484);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 30);
            this.label7.TabIndex = 28;
            this.label7.Text = "Locker";
            // 
            // OtherDetailsTextBox
            // 
            this.OtherDetailsTextBox.Location = new System.Drawing.Point(227, 536);
            this.OtherDetailsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.OtherDetailsTextBox.Multiline = true;
            this.OtherDetailsTextBox.Name = "OtherDetailsTextBox";
            this.OtherDetailsTextBox.Size = new System.Drawing.Size(397, 183);
            this.OtherDetailsTextBox.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 539);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 30);
            this.label8.TabIndex = 30;
            this.label8.Text = "Other Details";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(651, 467);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 30);
            this.label9.TabIndex = 33;
            this.label9.Text = "Category";
            this.label9.Visible = false;
            // 
            // CategoryComboBox
            // 
            this.CategoryComboBox.FormattingEnabled = true;
            this.CategoryComboBox.Items.AddRange(new object[] {
            "Open",
            "Closed"});
            this.CategoryComboBox.Location = new System.Drawing.Point(792, 464);
            this.CategoryComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.CategoryComboBox.Name = "CategoryComboBox";
            this.CategoryComboBox.Size = new System.Drawing.Size(390, 38);
            this.CategoryComboBox.TabIndex = 8;
            this.CategoryComboBox.Visible = false;
            // 
            // RFIDNoTextBox
            // 
            this.RFIDNoTextBox.Location = new System.Drawing.Point(784, 152);
            this.RFIDNoTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.RFIDNoTextBox.Name = "RFIDNoTextBox";
            this.RFIDNoTextBox.Size = new System.Drawing.Size(390, 36);
            this.RFIDNoTextBox.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(645, 154);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 30);
            this.label10.TabIndex = 35;
            this.label10.Text = "RFID No";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(643, 208);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(351, 30);
            this.label11.TabIndex = 37;
            this.label11.Text = "TuesdayLeague Night Membership";
            // 
            // TLNMTextBox
            // 
            this.TLNMTextBox.Location = new System.Drawing.Point(1008, 202);
            this.TLNMTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.TLNMTextBox.Name = "TLNMTextBox";
            this.TLNMTextBox.Size = new System.Drawing.Size(172, 36);
            this.TLNMTextBox.TabIndex = 10;
            this.TLNMTextBox.Text = "0";
            this.TLNMTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.THLNMTextBox_KeyPress);
            // 
            // THLNMTextBox
            // 
            this.THLNMTextBox.Location = new System.Drawing.Point(1008, 257);
            this.THLNMTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.THLNMTextBox.Name = "THLNMTextBox";
            this.THLNMTextBox.Size = new System.Drawing.Size(172, 36);
            this.THLNMTextBox.TabIndex = 11;
            this.THLNMTextBox.Text = "0";
            this.THLNMTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.THLNMTextBox_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(643, 263);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(365, 30);
            this.label12.TabIndex = 39;
            this.label12.Text = "Thursday League Night Membership";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(643, 353);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 30);
            this.label13.TabIndex = 42;
            this.label13.Text = "Status";
            // 
            // MembershipStatusComboBox
            // 
            this.MembershipStatusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MembershipStatusComboBox.FormattingEnabled = true;
            this.MembershipStatusComboBox.Items.AddRange(new object[] {
            "Expired Members",
            "Purchashed Membership",
            "Daily Paying Members"});
            this.MembershipStatusComboBox.Location = new System.Drawing.Point(791, 345);
            this.MembershipStatusComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.MembershipStatusComboBox.Name = "MembershipStatusComboBox";
            this.MembershipStatusComboBox.Size = new System.Drawing.Size(389, 38);
            this.MembershipStatusComboBox.TabIndex = 12;
            // 
            // AddNewMemeberScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 963);
            this.Controls.Add(this.MembershipStatusComboBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.THLNMTextBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.TLNMTextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.RFIDNoTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.CategoryComboBox);
            this.Controls.Add(this.OtherDetailsTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.LockerTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ExpiryDateDateTimePicker);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.MembershipDateDatetTimePicker);
            this.Controls.Add(this.MoneyPaidTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MembershipTypeComboBox);
            this.Controls.Add(this.LastNameTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FirstNameTextBox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "AddNewMemeberScreen";
            this.Padding = new System.Windows.Forms.Padding(27, 80, 27, 30);
            this.Text = "AddNewMemeberScreen";
            this.Load += new System.EventHandler(this.AddNewMemeberScreen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveButton;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem deleteButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox MembershipTypeComboBox;
        private System.Windows.Forms.TextBox LastNameTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox FirstNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox MoneyPaidTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker MembershipDateDatetTimePicker;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker ExpiryDateDateTimePicker;
        private System.Windows.Forms.TextBox LockerTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox OtherDetailsTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox CategoryComboBox;
        private System.Windows.Forms.TextBox RFIDNoTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TLNMTextBox;
        private System.Windows.Forms.TextBox THLNMTextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox MembershipStatusComboBox;
    }
}