﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Memembers
{
    public partial class AddNewMemeberScreen : TemplateForm
    {
        public AddNewMemeberScreen()
        {
            InitializeComponent();
        }
        public int MemberID { get; set; }
        public bool IsUpdate { get; set; }
        private void AddNewMemeberScreen_Load(object sender, EventArgs e)
        {
            try
            {
                LoadDataIntoComboBoxes();
                if (IsUpdate == true)
                {
                    LoadAndBindData();
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void LoadAndBindData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_MembersLoadForUpdateById", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.Parameters.AddWithValue("@MemberId", this.MemberID);
                        DataTable dtUsers = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtUsers.Load(sdr);
                        DataRow row = dtUsers.Rows[0];
                        FirstNameTextBox.Text = row["FirstName"].ToString();
                        LastNameTextBox.Text = row["LastName"].ToString();
                        MoneyPaidTextBox.Text = row["MoneyPaid"].ToString();
                        MembershipTypeComboBox.SelectedValue = row["MemembershipTypeId"];
                        MembershipDateDatetTimePicker.Value = Convert.ToDateTime(row["MemembershipPaidDate"]);
                        ExpiryDateDateTimePicker.Value = Convert.ToDateTime(row["MemembershipExpiryDate"]);
                        LockerTextBox.Text = row["Locker"].ToString();
                        OtherDetailsTextBox.Text = row["OtherDetails"].ToString();
                        CategoryComboBox.Text = row["Category"].ToString();
                        MembershipStatusComboBox.Text = row["MembershipStatus"].ToString();
                        RFIDNoTextBox.Text = row["RFIDNumber"].ToString();
                        TLNMTextBox.Text = row["TuesdayLeagueNightMembership"].ToString();
                        THLNMTextBox.Text = row["ThursdayLeagueNightMembership"].ToString();
                        saveButton.Text = "Update Record";
                        deleteButton.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void LoadDataIntoComboBoxes()
        {
            LoadMembershipTypes();
        }

        private void LoadMembershipTypes()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_MembershipTypesLoadDataIntoComboBox", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    MembershipTypeComboBox.DataSource = dtRoles;
                    MembershipTypeComboBox.DisplayMember = "MembershipTypeName";
                    MembershipTypeComboBox.ValueMember = "MemberShipTypeId";
                    MembershipTypeComboBox.SelectedIndex = -1;
                }
            }
        }

        private void IsUserActiveCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.IsUpdate)
                {
                    UpdateRecord();
                }
                else
                {
                    SaveRecord();
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void SaveRecord()
        {
            try
            {
                if (IsFormValid())
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_MembersAddNewMember", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;


                            cmd.Parameters.AddWithValue("@FirstName", FirstNameTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@LastName", LastNameTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@MoneyPaid", Convert.ToDecimal(MoneyPaidTextBox.Text.Trim()));
                            cmd.Parameters.AddWithValue("@MemembershipTypeId", (MembershipTypeComboBox.SelectedValue) == null ? 0 : MembershipTypeComboBox.SelectedValue);
                            cmd.Parameters.AddWithValue("@MemembershipPaidDate", MembershipDateDatetTimePicker.Value);
                            cmd.Parameters.AddWithValue("@MemembershipExpiryDate", ExpiryDateDateTimePicker.Value);
                            cmd.Parameters.AddWithValue("@Locker", LockerTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@OtherDetails", OtherDetailsTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@Category", CategoryComboBox.Text);
                            cmd.Parameters.AddWithValue("@MembershipStatus", MembershipStatusComboBox.Text);
                            cmd.Parameters.AddWithValue("@RFIDNumber", RFIDNoTextBox.Text);
                            cmd.Parameters.AddWithValue("@TuesdayLeagueNightMembership", Convert.ToInt32(TLNMTextBox.Text.Trim()));
                            cmd.Parameters.AddWithValue("@ThursdayLeagueNightMembership", Convert.ToInt32(THLNMTextBox.Text.Trim()));
                            cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);


                           

                    
           



                          
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            Alertify.Success("Member Added Successfully");
                            ResetFormControls();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }
       


        private void ResetFormControls()
        {
            FirstNameTextBox.Clear();
            LastNameTextBox.Clear();
            MoneyPaidTextBox.Clear();
            MembershipTypeComboBox.SelectedIndex = -1;
            MembershipDateDatetTimePicker.Value = DateTime.Now;
            ExpiryDateDateTimePicker.Value = DateTime.Now;
            LockerTextBox.Clear();
            MoneyPaidTextBox.Clear();
            CategoryComboBox.SelectedIndex = -1;
            RFIDNoTextBox.Clear();
            THLNMTextBox.Clear();
            TLNMTextBox.Clear();
            MembershipStatusComboBox.SelectedIndex = -1;
            OtherDetailsTextBox.Clear();
            FirstNameTextBox.Focus();
            if (this.IsUpdate)
            {
                this.MemberID = 0;
                this.IsUpdate = false;
                saveButton.Text = "Save Record";
                deleteButton.Enabled = false;
            }

        }

        private bool IsFormValid()
        {
            if (FirstNameTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("First Name is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FirstNameTextBox.Focus();
                return false;
            }
            //if (LastNameTextBox.Text.Trim() == string.Empty)
            //{
            //    MessageBox.Show("Last Name is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    LastNameTextBox.Focus();
            //    return false;
            //}
            //if (MembershipTypeComboBox.SelectedIndex == -1)
            //{
            //    MessageBox.Show("Membership Type is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    MembershipTypeComboBox.Focus();
            //    return false;
            //}
            return true;
        }

        private void UpdateRecord()
        {
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_MembersUpdateMember", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MemberId", this.MemberID);
                        cmd.Parameters.AddWithValue("@FirstName", FirstNameTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@LastName", LastNameTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@MoneyPaid", Convert.ToDecimal(MoneyPaidTextBox.Text.Trim()));
                        cmd.Parameters.AddWithValue("@MemembershipTypeId", (MembershipTypeComboBox.SelectedValue) == null ? 0 : MembershipTypeComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@MemembershipPaidDate", MembershipDateDatetTimePicker.Value);
                        cmd.Parameters.AddWithValue("@MemembershipExpiryDate", ExpiryDateDateTimePicker.Value);
                        cmd.Parameters.AddWithValue("@Locker", LockerTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@OtherDetails", OtherDetailsTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@Category", CategoryComboBox.Text);
                        cmd.Parameters.AddWithValue("@MembershipStatus", MembershipStatusComboBox.Text);
                        cmd.Parameters.AddWithValue("@RFIDNumber", RFIDNoTextBox.Text);
                        cmd.Parameters.AddWithValue("@TuesdayLeagueNightMembership", Convert.ToInt32(TLNMTextBox.Text.Trim()));
                        cmd.Parameters.AddWithValue("@ThursdayLeagueNightMembership", Convert.ToInt32(THLNMTextBox.Text.Trim()));
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        Alertify.Success("Member Updated Successfully");
                        ResetFormControls();
                    }
                }
            }
        }

        private void THLNMTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetFormControls();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteRecord();
        }

        private void DeleteRecord()
        {
            if (this.IsUpdate)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this Member", "Confirm Operation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_MembersDeleteMember", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@MemberId", this.MemberID);
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Member Deleted Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ResetFormControls();

                        }
                    }
                }
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void MembershipDateDatetTimePicker_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if(MembershipTypeComboBox.SelectedIndex==6)
                {
                    ExpiryDateDateTimePicker.Value = DateTime.Now;
                }
                else
                {
                    ExpiryDateDateTimePicker.Value = MembershipDateDatetTimePicker.Value.AddMonths(3);
                }
                
            }
            catch (Exception x)
            {

                Alertify.Error(x.Message);
            }
        }
    }
}
