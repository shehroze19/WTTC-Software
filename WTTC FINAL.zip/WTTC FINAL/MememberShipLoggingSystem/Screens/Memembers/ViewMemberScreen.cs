﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Memembers
{
    public partial class ViewMemberScreen : TemplateForm
    {
        public ViewMemberScreen()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void refreshScreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
        }

        private void LoadDataIntoGridView()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_MembersLoadDataIntoGridView", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    dgvUsers.DataSource = dtRoles;
                }
            }
        }

        private void ViewMemberScreen_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
        }

        private void dgvUsers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int memberid = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells[0].Value);
                AddNewMemeberScreen addnew = new AddNewMemeberScreen();
                addnew.MemberID = memberid;
                addnew.IsUpdate = true;
                addnew.ShowDialog();
                LoadDataIntoGridView();
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_MembersSearchAndLoadData", con))
                    {
                     
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Filter", txtSearch.Text.Trim());
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        DataTable dtRole = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            dtRole.Load(sdr);
                            dgvUsers.DataSource = dtRole;
                        }
                        else
                        {
                            MessageBox.Show("No Records Were Found", "No Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                }
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchAndLoadDateWise();
        }

        private void SearchAndLoadDateWise()
        {
            if (txtSearch.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_MembersSearchAndLoadDataDateWise", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Filter", txtSearch.Text.Trim());
                        cmd.Parameters.AddWithValue("@PaidDate", MembershipDateDatetTimePicker.Value.ToShortDateString());
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        DataTable dtRole = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        if (sdr.HasRows)
                        {
                            dtRole.Load(sdr);
                            dgvUsers.DataSource = dtRole;
                        }
                        else
                        {
                            MessageBox.Show("No Records Were Found", "No Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    }
                }
            }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void saveRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewMemeberScreen addnew = new AddNewMemeberScreen();
            addnew.ShowDialog();
        }

        private void ExportToExcelButton_Click(object sender, EventArgs e)
        {
            if(dgvUsers.Rows.Count>0)
            {
                try
                {
                    // creating Excel Application  
                    Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                    // creating new WorkBook within Excel application  
                    Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                    // creating new Excelsheet in workbook  
                    Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                    // see the excel sheet behind the program  
                    app.Visible = true;
                    // get the reference of first sheet. By default its name is Sheet1.  
                    // store its reference to worksheet  
                    worksheet = workbook.Sheets["Sheet1"];
                    worksheet = workbook.ActiveSheet;
                    // changing the name of active sheet  
                    worksheet.Name = "Members";
                    // storing header part in Excel  
                    for (int i = 1; i < dgvUsers.Columns.Count + 1; i++)
                    {
                        worksheet.Cells[1, i] = dgvUsers.Columns[i - 1].HeaderText;
                    }
                    // storing Each row and column value to excel sheet  
                    for (int i = 0; i < dgvUsers.Rows.Count; i++)
                    {
                        for (int j = 0; j < dgvUsers.Columns.Count; j++)
                        {
                            worksheet.Cells[i + 2, j + 1] = dgvUsers.Rows[i].Cells[j].Value.ToString();
                        }
                    }
                    // save the application  
                    String FilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFo‌​lder.Desktop), "Member Details " + DateTime.Now.ToString("dd-MM-yyyy HH mm") + ".xlsx");
                    workbook.SaveAs(FilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    MessageBox.Show("Member Details Exported Successfully the File is Saved on desktop with name " + "Log Details " + DateTime.Now.ToString("dd-MM-yyyy HH mm") + ".xlsx", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                catch (Exception ex)
                {

                    Alertify.Error(ex.Message);
                }
            }
        }
    }
}
