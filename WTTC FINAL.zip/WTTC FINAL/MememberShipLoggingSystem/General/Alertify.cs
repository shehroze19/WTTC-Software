﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.General
{
    class Alertify
    {
        
            public static void Success()
            {
                MessageBox.Show("Your Request Performed Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            public static void Success(string msg)
            {
                MessageBox.Show(msg, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            public static void Success(string msg, string caption)
            {
                MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            //error

            public static void Error()
            {
                MessageBox.Show("Something went wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            public static void Error(string msg)
            {
                MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            public static void Error(string msg, string caption)
            {
                MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //confirmation
            public static bool Confirm()
            {
                DialogResult result = MessageBox.Show("Are you sure you want to perform this operation?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                return (result == DialogResult.Yes) ? true : false;
            }
            public static bool Confirm(string msg)
            {
                DialogResult result = MessageBox.Show(msg, "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                return (result == DialogResult.Yes) ? true : false;
            }
        }
    
}
