﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Memembers
{
    public partial class AddNewMemeberScreen : TemplateForm
    {
        public AddNewMemeberScreen()
        {
            InitializeComponent();
        }
        public int MemberID { get; set; }
        public bool IsUpdate { get; set; }
        private void AddNewMemeberScreen_Load(object sender, EventArgs e)
        {
            try
            {
                MemberType.SelectedIndex = 0;
                LoadDataIntoComboBoxes();
                if (IsUpdate == true)
                {
                    LoadAndBindData();
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void LoadAndBindData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_MembersLoadForUpdateById", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.Parameters.AddWithValue("@MemberId", this.MemberID);
                        DataTable dtUsers = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtUsers.Load(sdr);
                        DataRow row = dtUsers.Rows[0];
                        FirstNameTextBox.Text = row["FirstName"].ToString();
                        LastNameTextBox.Text = row["LastName"].ToString();
                        MoneyPaidTextBox.Text = row["MoneyPaid"].ToString();
                        MembershipTypeComboBox.SelectedValue = row["MemembershipTypeId"];
                        MembershipDateDatetTimePicker.Value = Convert.ToDateTime(row["MemembershipPaidDate"]);
                        ExpiryDateDateTimePicker.Value = Convert.ToDateTime(row["MemembershipExpiryDate"]);
                        LockerTextBox.Text = row["Locker"].ToString();
                        OtherDetailsTextBox.Text = row["OtherDetails"].ToString();
                        CategoryComboBox.Text = row["Category"].ToString();
                        MembershipStatusComboBox.Text = row["MembershipStatus"].ToString();
                        RFIDNoTextBox.Text = row["RFIDNumber"].ToString();
                        TLNMTextBox.Text = row["TuesdayLeagueNightMembership"].ToString();
                        THLNMTextBox.Text = row["ThursdayLeagueNightMembership"].ToString();
                        MemberType.Text = row["Type"].ToString();
                        RoleComboBox.Text = row["Role"].ToString();
                        SwipesTextBox.Text = row["Swipes"].ToString();
                        saveButton.Text = "Update Record";
                        deleteButton.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void LoadDataIntoComboBoxes()
        {
            LoadMembershipTypes();
        }

        private void LoadMembershipTypes()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_MembershipTypesLoadDataIntoComboBox", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    MembershipTypeComboBox.DataSource = dtRoles;
                    MembershipTypeComboBox.DisplayMember = "MembershipTypeName";
                    MembershipTypeComboBox.ValueMember = "MemberShipTypeId";
                    MembershipTypeComboBox.SelectedIndex = -1;
                }
            }
        }

        private void IsUserActiveCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.IsUpdate)
                {
                    UpdateRecord();
                }
                else
                {
                    SaveRecord();
                }
            }
            catch (Exception ex)
            {

                Alertify.Error(ex.Message);
            }
        }

        private void SaveRecord()
        {
            try
            {
                if (IsFormValid())
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_MembersAddNewMember", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@FirstName", FirstNameTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@LastName", LastNameTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@MoneyPaid", Convert.ToDecimal(MoneyPaidTextBox.Text.Trim()));
                            cmd.Parameters.AddWithValue("@MemembershipTypeId", (MembershipTypeComboBox.SelectedValue) ?? 0);
                            cmd.Parameters.AddWithValue("@MemembershipPaidDate", MembershipDateDatetTimePicker.Value);
                            cmd.Parameters.AddWithValue("@MemembershipExpiryDate", ExpiryDateDateTimePicker.Value);
                            cmd.Parameters.AddWithValue("@Locker", LockerTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@OtherDetails", OtherDetailsTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@Category", CategoryComboBox.Text);
                            cmd.Parameters.AddWithValue("@MembershipStatus", MembershipStatusComboBox.Text);
                            cmd.Parameters.AddWithValue("@RFIDNumber", RFIDNoTextBox.Text);
                            cmd.Parameters.AddWithValue("@TuesdayLeagueNightMembership", Convert.ToInt32(TLNMTextBox.Text.Trim()));
                            cmd.Parameters.AddWithValue("@ThursdayLeagueNightMembership", Convert.ToInt32(THLNMTextBox.Text.Trim()));
                            cmd.Parameters.AddWithValue("@Type", MemberType.Text);
                            cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);

                            if (con.State != ConnectionState.Open)
                                con.Open();

                            int lastId = Convert.ToInt32(cmd.ExecuteScalar());

                            if (lastId > 0 && MemberType.SelectedIndex == 1)
                            {
                                using (SqlCommand cmd2 = new SqlCommand("INSERT INTO PPP(MemberId, Role, Swipes, CreatedBy) VALUES(@MemberId, @Role, @Swipes, @CreatedBy)", con))
                                {
                                    cmd2.Parameters.AddWithValue("@MemberId", lastId);
                                    cmd2.Parameters.AddWithValue("@Role", RoleComboBox.Text.Trim());
                                    cmd2.Parameters.AddWithValue("@Swipes", SwipesTextBox.Text.Trim());
                                    cmd2.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                                    cmd2.ExecuteNonQuery();
                                }
                            }

                            // ✅ Insert the new member into history
                            InsertNewMemberHistory(lastId, con);

                            Alertify.Success("Member Added Successfully");
                            ResetFormControls();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Alertify.Error(ex.Message);
            }
        }

        private void InsertNewMemberHistory(int memberId, SqlConnection con)
        {
            using (SqlCommand historyCmd = new SqlCommand("INSERT INTO MemembersHistory " +
                "(MemberId, FirstName, LastName, MoneyPaid, MemembershipTypeId, MemembershipPaidDate, MemembershipExpiryDate, Locker, OtherDetails, " +
                "Category, MembershipStatus, RFIDNumber, TuesdayLeagueNightMembership, ThursdayLeagueNightMembership, Type, CreatedBy, CreatedDate) " +
                "VALUES (@MemberId, @FirstName, @LastName, @MoneyPaid, @MemembershipTypeId, @MemembershipPaidDate, @MemembershipExpiryDate, @Locker, @OtherDetails, " +
                "@Category, @MembershipStatus, @RFIDNumber, @TuesdayLeagueNightMembership, @ThursdayLeagueNightMembership, @Type, @CreatedBy, GETDATE())", con))
            {
                historyCmd.Parameters.AddWithValue("@MemberId", memberId);
                historyCmd.Parameters.AddWithValue("@FirstName", FirstNameTextBox.Text.Trim());
                historyCmd.Parameters.AddWithValue("@LastName", LastNameTextBox.Text.Trim());
                historyCmd.Parameters.AddWithValue("@MoneyPaid", Convert.ToDecimal(MoneyPaidTextBox.Text.Trim()));
                historyCmd.Parameters.AddWithValue("@MemembershipTypeId", (MembershipTypeComboBox.SelectedValue) ?? 0);
                historyCmd.Parameters.AddWithValue("@MemembershipPaidDate", MembershipDateDatetTimePicker.Value);
                historyCmd.Parameters.AddWithValue("@MemembershipExpiryDate", ExpiryDateDateTimePicker.Value);
                historyCmd.Parameters.AddWithValue("@Locker", LockerTextBox.Text.Trim());
                historyCmd.Parameters.AddWithValue("@OtherDetails", OtherDetailsTextBox.Text.Trim());
                historyCmd.Parameters.AddWithValue("@Category", CategoryComboBox.Text);
                historyCmd.Parameters.AddWithValue("@MembershipStatus", MembershipStatusComboBox.Text);
                historyCmd.Parameters.AddWithValue("@RFIDNumber", RFIDNoTextBox.Text);
                historyCmd.Parameters.AddWithValue("@TuesdayLeagueNightMembership", Convert.ToInt32(TLNMTextBox.Text.Trim()));
                historyCmd.Parameters.AddWithValue("@ThursdayLeagueNightMembership", Convert.ToInt32(THLNMTextBox.Text.Trim()));
                historyCmd.Parameters.AddWithValue("@Type", MemberType.Text);
                historyCmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);

                if (con.State != ConnectionState.Open)
                    con.Open();
                historyCmd.ExecuteNonQuery();
            }
        }



        private void ResetFormControls()
        {
            FirstNameTextBox.Clear();
            LastNameTextBox.Clear();
            MoneyPaidTextBox.Text = "0";
            MembershipTypeComboBox.SelectedIndex = -1;
            MembershipDateDatetTimePicker.Value = DateTime.Now;
            ExpiryDateDateTimePicker.Value = DateTime.Now;
            LockerTextBox.Clear();
          
            CategoryComboBox.SelectedIndex = -1;
            RFIDNoTextBox.Clear();
            THLNMTextBox.Text = "0";
            TLNMTextBox.Text = "0";
            MembershipStatusComboBox.SelectedIndex = -1;
            OtherDetailsTextBox.Clear();
            FirstNameTextBox.Focus();
            MemberType.SelectedIndex = 0;
            SwipesTextBox.Text = "0";
            RoleComboBox.SelectedIndex = -1;
            if (this.IsUpdate)
            {
                this.MemberID = 0;
                this.IsUpdate = false;
                saveButton.Text = "Save Record";
                deleteButton.Enabled = false;
            }

        }

        private bool IsFormValid()
        {
            if (FirstNameTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("First Name is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FirstNameTextBox.Focus();
                return false;
            }
            if (MemberType.SelectedIndex==1 && RoleComboBox.SelectedIndex ==-1)
            {
                MessageBox.Show("Role is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                RoleComboBox.Focus();
                return false;
            }
            if (MemberType.SelectedIndex == 1 && SwipesTextBox.Text==string.Empty)
            {
                MessageBox.Show("No of Swipes are Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SwipesTextBox.Focus();
                return false;
            }

            return true;
        }


        private void UpdateRecord()
        {
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    if (con.State != ConnectionState.Open)
                        con.Open();

                    // Step 1: Fetch OLD member data before update
                    DataRow oldData = FetchOldMemberData(this.MemberID, con);
                    if (oldData != null)
                    {
                        // Step 2: Insert OLD record into MemembersHistory
                        InsertMemberHistory(oldData, con);
                    }

                    // Step 3: Update the member record
                    using (SqlCommand cmd = new SqlCommand("usp_MembersUpdateMember", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MemberId", this.MemberID);
                        cmd.Parameters.AddWithValue("@FirstName", FirstNameTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@LastName", LastNameTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@MoneyPaid", Convert.ToDecimal(MoneyPaidTextBox.Text.Trim()));
                        cmd.Parameters.AddWithValue("@MemembershipTypeId", (MembershipTypeComboBox.SelectedValue) ?? 0);
                        cmd.Parameters.AddWithValue("@MemembershipPaidDate", MembershipDateDatetTimePicker.Value);
                        cmd.Parameters.AddWithValue("@MemembershipExpiryDate", ExpiryDateDateTimePicker.Value);
                        cmd.Parameters.AddWithValue("@Locker", LockerTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@OtherDetails", OtherDetailsTextBox.Text.Trim());
                        cmd.Parameters.AddWithValue("@Category", CategoryComboBox.Text);
                        cmd.Parameters.AddWithValue("@MembershipStatus", MembershipStatusComboBox.Text);
                        cmd.Parameters.AddWithValue("@RFIDNumber", RFIDNoTextBox.Text);
                        cmd.Parameters.AddWithValue("@TuesdayLeagueNightMembership", Convert.ToInt32(TLNMTextBox.Text.Trim()));
                        cmd.Parameters.AddWithValue("@ThursdayLeagueNightMembership", Convert.ToInt32(THLNMTextBox.Text.Trim()));
                        cmd.Parameters.AddWithValue("@Type", MemberType.Text);
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        cmd.ExecuteScalar();
                    }

                    // Step 4: Fetch NEW member data after update
                    DataRow newData = FetchNewMemberData();

                    // Step 5: Insert NEW record into MemembersHistory
                    InsertMemberHistory(newData, con);

                    // Step 6: Update Parkinson's-related data if applicable
                    if (this.MemberID > 0 && MemberType.SelectedIndex == 1)
                    {
                        using (SqlCommand cmd2 = new SqlCommand("UPDATE PPP SET Role = @Role, Swipes = @Swipes, CreatedBy = @CreatedBy WHERE MemberId = @MemberId", con))
                        {
                            cmd2.Parameters.AddWithValue("@MemberId", this.MemberID);
                            cmd2.Parameters.AddWithValue("@Role", RoleComboBox.Text.Trim());
                            cmd2.Parameters.AddWithValue("@Swipes", SwipesTextBox.Text.Trim());
                            cmd2.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                            cmd2.ExecuteNonQuery();
                        }
                    }

                    Alertify.Success("Member Updated Successfully");
                    ResetFormControls();
                }
            }
        }

        private DataRow FetchOldMemberData(int memberId, SqlConnection con)
        {
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Memembers WHERE MemberId = @MemberId", con))
            {
                cmd.Parameters.AddWithValue("@MemberId", memberId);
                if (con.State != ConnectionState.Open)
                    con.Open();

                DataTable dt = new DataTable();
                SqlDataReader reader = cmd.ExecuteReader();
                dt.Load(reader);
                return dt.Rows.Count > 0 ? dt.Rows[0] : null;
            }
        }

        private DataRow FetchNewMemberData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MemberId");
            dt.Columns.Add("FirstName");
            dt.Columns.Add("LastName");
            dt.Columns.Add("MoneyPaid");
            dt.Columns.Add("MemembershipTypeId");
            dt.Columns.Add("MemembershipPaidDate");
            dt.Columns.Add("MemembershipExpiryDate");
            dt.Columns.Add("Locker");
            dt.Columns.Add("OtherDetails");
            dt.Columns.Add("Category");
            dt.Columns.Add("MembershipStatus");
            dt.Columns.Add("RFIDNumber");
            dt.Columns.Add("TuesdayLeagueNightMembership");
            dt.Columns.Add("ThursdayLeagueNightMembership");
            dt.Columns.Add("Type");

            DataRow row = dt.NewRow();
            row["MemberId"] = this.MemberID;
            row["FirstName"] = FirstNameTextBox.Text.Trim();
            row["LastName"] = LastNameTextBox.Text.Trim();
            row["MoneyPaid"] = Convert.ToDecimal(MoneyPaidTextBox.Text.Trim());
            row["MemembershipTypeId"] = MembershipTypeComboBox.SelectedValue ?? 0;
            row["MemembershipPaidDate"] = MembershipDateDatetTimePicker.Value;
            row["MemembershipExpiryDate"] = ExpiryDateDateTimePicker.Value;
            row["Locker"] = LockerTextBox.Text.Trim();
            row["OtherDetails"] = OtherDetailsTextBox.Text.Trim();
            row["Category"] = CategoryComboBox.Text;
            row["MembershipStatus"] = MembershipStatusComboBox.Text;
            row["RFIDNumber"] = RFIDNoTextBox.Text;
            row["TuesdayLeagueNightMembership"] = Convert.ToInt32(TLNMTextBox.Text.Trim());
            row["ThursdayLeagueNightMembership"] = Convert.ToInt32(THLNMTextBox.Text.Trim());
            row["Type"] = MemberType.Text;

            dt.Rows.Add(row);
            return row;
        }

        private void InsertMemberHistory(DataRow memberData, SqlConnection con)
        {
            using (SqlCommand historyCmd = new SqlCommand("INSERT INTO MemembersHistory " +
                "(MemberId, FirstName, LastName, MoneyPaid, MemembershipTypeId, MemembershipPaidDate, MemembershipExpiryDate, Locker, OtherDetails, " +
                "Category, MembershipStatus, RFIDNumber, TuesdayLeagueNightMembership, ThursdayLeagueNightMembership, Type, CreatedBy, CreatedDate) " +
                "VALUES (@MemberId, @FirstName, @LastName, @MoneyPaid, @MemembershipTypeId, @MemembershipPaidDate, @MemembershipExpiryDate, @Locker, @OtherDetails, " +
                "@Category, @MembershipStatus, @RFIDNumber, @TuesdayLeagueNightMembership, @ThursdayLeagueNightMembership, @Type, @CreatedBy, GETDATE())", con))
            {
                historyCmd.Parameters.AddWithValue("@MemberId", memberData["MemberId"]);
                historyCmd.Parameters.AddWithValue("@FirstName", memberData["FirstName"].ToString());
                historyCmd.Parameters.AddWithValue("@LastName", memberData["LastName"].ToString());
                historyCmd.Parameters.AddWithValue("@MoneyPaid", Convert.ToDecimal(memberData["MoneyPaid"]));
                historyCmd.Parameters.AddWithValue("@MemembershipTypeId", memberData["MemembershipTypeId"]);
                historyCmd.Parameters.AddWithValue("@MemembershipPaidDate", Convert.ToDateTime(memberData["MemembershipPaidDate"]));
                historyCmd.Parameters.AddWithValue("@MemembershipExpiryDate", Convert.ToDateTime(memberData["MemembershipExpiryDate"]));
                historyCmd.Parameters.AddWithValue("@Locker", memberData["Locker"].ToString());
                historyCmd.Parameters.AddWithValue("@OtherDetails", memberData["OtherDetails"].ToString());
                historyCmd.Parameters.AddWithValue("@Category", memberData["Category"].ToString());
                historyCmd.Parameters.AddWithValue("@MembershipStatus", memberData["MembershipStatus"].ToString());
                historyCmd.Parameters.AddWithValue("@RFIDNumber", memberData["RFIDNumber"].ToString());
                historyCmd.Parameters.AddWithValue("@TuesdayLeagueNightMembership", Convert.ToInt32(memberData["TuesdayLeagueNightMembership"]));
                historyCmd.Parameters.AddWithValue("@ThursdayLeagueNightMembership", Convert.ToInt32(memberData["ThursdayLeagueNightMembership"]));
                historyCmd.Parameters.AddWithValue("@Type", memberData["Type"].ToString());
                historyCmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);

                if (con.State != ConnectionState.Open)
                    con.Open();
                historyCmd.ExecuteNonQuery();
            }
        }





        private void THLNMTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetFormControls();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteRecord();
        }

        private void DeleteRecord()
        {
            if (this.IsUpdate)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this Member", "Confirm Operation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_MembersDeleteMember", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@MemberId", this.MemberID);
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Member Deleted Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ResetFormControls();

                        }
                    }
                }
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void MembershipDateDatetTimePicker_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if(MembershipTypeComboBox.SelectedIndex==6)
                {
                    ExpiryDateDateTimePicker.Value = DateTime.Now;
                }
                else
                {
                    ExpiryDateDateTimePicker.Value = MembershipDateDatetTimePicker.Value.AddMonths(3);
                }
                
            }
            catch (Exception x)
            {

                Alertify.Error(x.Message);
            }
        }


        private void MemberType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(MemberType.SelectedIndex == 1)
            {
                parkinsonGroupBox.Visible = true;
            }
            else
            {
                parkinsonGroupBox.Visible = false;
            }
        }

        private void SwipesTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }



        private void MembershipTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (MembershipTypeComboBox.SelectedValue != null)
                {
                    DateTime membershipStartDate = MembershipDateDatetTimePicker.Value;
                    DateTime newExpiryDate = membershipStartDate; // Default to start date

                    string selectedMembership = MembershipTypeComboBox.Text; // Get selected membership type

                    if (!string.IsNullOrEmpty(selectedMembership))
                    {
                        if (IsUpdate) // If this is an update operation
                        {
                            // If expiry date already exists, do not reset it
                            if (ExpiryDateDateTimePicker.Value != null && ExpiryDateDateTimePicker.Value > membershipStartDate)
                            {
                                return; // Keep the existing expiry date
                            }
                        }

                        // If it's a new member or expiry date is not set, update accordingly
                        if (selectedMembership.Contains("12 months"))
                        {
                            newExpiryDate = membershipStartDate.AddYears(1); // Add 12 months
                        }
                        else if (selectedMembership.Contains("6 months"))
                        {
                            newExpiryDate = membershipStartDate.AddMonths(6); // Add 6 months
                        }
                        else if (selectedMembership.Contains("3 months"))
                        {
                            newExpiryDate = membershipStartDate.AddMonths(3); // Add 3 months
                        }
                        // Custom or other cases, keep it unchanged
                    }

                    // Update the expiry date dynamically only if it's a new record
                    ExpiryDateDateTimePicker.Value = newExpiryDate;
                }
            }
            catch (Exception ex)
            {
                Alertify.Error(ex.Message);
            }
        }



        private void ExpiryDateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
