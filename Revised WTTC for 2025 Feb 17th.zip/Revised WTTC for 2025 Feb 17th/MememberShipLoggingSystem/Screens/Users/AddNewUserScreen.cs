﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens.Users
{
    public partial class AddNewUserScreen : TemplateForm
    {
        public AddNewUserScreen()
        {
            InitializeComponent();
        }
        public string UserName { get; set; }
        public bool IsUpdate { get; set; }
        private void AddNewUserScreen_Load(object sender, EventArgs e)
        {
            LoadDataIntoCombox();

            // load for update
            if (IsUpdate == true)
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_UsersReloadDataForUpdate", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.Parameters.AddWithValue("@UserName", this.UserName);
                        DataTable dtUsers = new DataTable();
                        SqlDataReader sdr = cmd.ExecuteReader();
                        dtUsers.Load(sdr);
                        DataRow row = dtUsers.Rows[0];
                        txtUserName.Text = row["UserName"].ToString();
                        cmbRoll.SelectedValue = row["RoleId"];
                        IsUserActiveCheckBox.Checked = Convert.ToBoolean(row["IsActive"]);
                        txtDescription.Text = row["Description"].ToString();
                        saveButton.Text = "Update Record";
                        deleteButton.Enabled = true;
                    }
                }
            }
        }

        private void LoadDataIntoCombox()
        {
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand("usp_RolesLoadDataIntoComboBox", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    DataTable dtRoles = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    dtRoles.Load(sdr);
                    cmbRoll.DataSource = dtRoles;
                    cmbRoll.DisplayMember = "RoleTitle";
                    cmbRoll.ValueMember = "RoleId";
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (this.IsUpdate)
            {
                UpdateRecord();
            }
            else
            {
                SaveRecord();
            }
        }

        private void SaveRecord()
        {
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_UsersAddNewUser", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserName", txtUserName.Text.Trim());
                        cmd.Parameters.AddWithValue("@Password", SecureData.EncryptData(txtPassword.Text.Trim()));
                        cmd.Parameters.AddWithValue("@RoleId", Convert.ToInt32(cmbRoll.SelectedValue));
                        cmd.Parameters.AddWithValue("@IsActive", IsUserActiveCheckBox.Checked);
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("User Added Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ResetFormControls();
                    }
                }
            }
        }

        private bool IsFormValid()
        {
            if (txtUserName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("UserName is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserName.Focus();
                return false;
            }
            if (txtPassword.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Password is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserName.Focus();
                return false;
            }
            if (txtDescription.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Description is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDescription.Focus();
                return false;
            }
            return true;
        }

        private void ResetFormControls()
        {
            txtUserName.Clear();
            txtPassword.Clear();
            IsUserActiveCheckBox.Checked = true;
            txtDescription.Clear();
            cmbRoll.SelectedIndex = 0;
            txtUserName.Focus();
            if (this.IsUpdate)
            {
                this.UserName = null;
                this.IsUpdate = false;
                saveButton.Text = "Save Record";
                deleteButton.Enabled = false;
            }

        }

        private void UpdateRecord()
        {
            if (IsFormValid())
            {
                using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                {
                    using (SqlCommand cmd = new SqlCommand("usp_UsersUpdateUser", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@OldUserName", this.UserName);
                        cmd.Parameters.AddWithValue("@UserName", txtUserName.Text.Trim());
                        cmd.Parameters.AddWithValue("@Password", SecureData.EncryptData(txtPassword.Text.Trim()));
                        cmd.Parameters.AddWithValue("@RoleId", Convert.ToInt32(cmbRoll.SelectedValue));
                        cmd.Parameters.AddWithValue("@IsActive", IsUserActiveCheckBox.Checked);
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                        cmd.Parameters.AddWithValue("@CreatedBy", LoggedInUser.UserName);
                        if (con.State != ConnectionState.Open)
                            con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("User Updated Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ResetFormControls();
                    }
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (this.IsUpdate)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this User", "Confirm Operation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_UsersDeleteUserByUserName", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@UserName", this.UserName);
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("User Deleted Successfully!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ResetFormControls();

                        }
                    }
                }
            }
        }
    }
}
