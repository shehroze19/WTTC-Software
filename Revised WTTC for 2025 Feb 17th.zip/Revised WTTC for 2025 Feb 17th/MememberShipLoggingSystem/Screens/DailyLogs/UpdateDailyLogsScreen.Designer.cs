﻿namespace MememberShipLoggingSystem.Screens.DailyLogs
{
    partial class UpdateDailyLogsScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveButton = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteButton = new System.Windows.Forms.ToolStripMenuItem();
            this.label6 = new System.Windows.Forms.Label();
            this.LogDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.MemberNameComboBox = new System.Windows.Forms.ComboBox();
            this.MoneyPaidTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.OtherDetailsTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveButton,
            this.toolStripMenuItem2,
            this.deleteButton});
            this.menuStrip1.Location = new System.Drawing.Point(27, 90);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(490, 33);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(67, 29);
            this.closeToolStripMenuItem.Text = "&Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(28, 29);
            this.toolStripMenuItem1.Text = "|";
            // 
            // saveButton
            // 
            this.saveButton.Name = "saveButton";
            this.saveButton.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveButton.Size = new System.Drawing.Size(121, 29);
            this.saveButton.Text = "&Save Record";
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(28, 29);
            this.toolStripMenuItem2.Text = "|";
            // 
            // deleteButton
            // 
            this.deleteButton.Enabled = false;
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.deleteButton.Size = new System.Drawing.Size(74, 29);
            this.deleteButton.Text = "&Delete";
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 160);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 30);
            this.label6.TabIndex = 27;
            this.label6.Text = "Log Date";
            // 
            // LogDateDateTimePicker
            // 
            this.LogDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.LogDateDateTimePicker.Location = new System.Drawing.Point(165, 155);
            this.LogDateDateTimePicker.Name = "LogDateDateTimePicker";
            this.LogDateDateTimePicker.Size = new System.Drawing.Size(325, 36);
            this.LogDateDateTimePicker.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 218);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 30);
            this.label3.TabIndex = 29;
            this.label3.Text = "Member";
            // 
            // MemberNameComboBox
            // 
            this.MemberNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MemberNameComboBox.FormattingEnabled = true;
            this.MemberNameComboBox.Location = new System.Drawing.Point(165, 210);
            this.MemberNameComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.MemberNameComboBox.Name = "MemberNameComboBox";
            this.MemberNameComboBox.Size = new System.Drawing.Size(325, 38);
            this.MemberNameComboBox.TabIndex = 28;
            // 
            // MoneyPaidTextBox
            // 
            this.MoneyPaidTextBox.Location = new System.Drawing.Point(163, 274);
            this.MoneyPaidTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MoneyPaidTextBox.Name = "MoneyPaidTextBox";
            this.MoneyPaidTextBox.Size = new System.Drawing.Size(327, 36);
            this.MoneyPaidTextBox.TabIndex = 30;
            this.MoneyPaidTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MoneyPaidTextBox_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 274);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 30);
            this.label5.TabIndex = 31;
            this.label5.Text = "Money Paid";
            // 
            // OtherDetailsTextBox
            // 
            this.OtherDetailsTextBox.Location = new System.Drawing.Point(163, 335);
            this.OtherDetailsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.OtherDetailsTextBox.Multiline = true;
            this.OtherDetailsTextBox.Name = "OtherDetailsTextBox";
            this.OtherDetailsTextBox.Size = new System.Drawing.Size(327, 176);
            this.OtherDetailsTextBox.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 338);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 30);
            this.label8.TabIndex = 33;
            this.label8.Text = "Other Details";
            // 
            // UpdateDailyLogsScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 568);
            this.Controls.Add(this.OtherDetailsTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.MoneyPaidTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MemberNameComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.LogDateDateTimePicker);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "UpdateDailyLogsScreen";
            this.Padding = new System.Windows.Forms.Padding(27, 90, 27, 30);
            this.Text = "Update Log Entry";
            this.Load += new System.EventHandler(this.UpdateDailyLogsScreen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveButton;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem deleteButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker LogDateDateTimePicker;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox MemberNameComboBox;
        private System.Windows.Forms.TextBox MoneyPaidTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox OtherDetailsTextBox;
        private System.Windows.Forms.Label label8;
    }
}