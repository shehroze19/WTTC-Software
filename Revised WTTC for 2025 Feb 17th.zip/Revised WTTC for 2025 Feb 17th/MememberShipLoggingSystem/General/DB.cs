﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MememberShipLoggingSystem.General
{
    class DB
    {
        public static bool IsDataExists(string query, SqlParameter parameter)
        {
            bool isExists = false;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue(parameter.ParameterName, parameter.Value);
                    if (con.State != ConnectionState.Open)
                        con.Open();

                    isExists = Convert.ToBoolean(cmd.ExecuteScalar());
                }
            }
            return isExists;
        }
        public static DataTable GetDataList(string storedprocedure)
        {

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand(storedprocedure, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (con.State != ConnectionState.Open)
                        con.Open();

                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        dt.Load(sdr);
                    }
                }
            }
            return dt;
        }

        // get data table with single parameter
        public static DataTable GetDataList(string storedprocedure, SqlParameter parameter)
        {

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand(storedprocedure, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(parameter.ParameterName, parameter.Value);
                    if (con.State != ConnectionState.Open)
                        con.Open();

                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        dt.Load(sdr);
                    }
                }
            }
            return dt;
        }

        // get data table with multiple parameters
        public static DataTable GetDataList(string storedprocedure, List<SqlParameter> parameters)
        {

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand(storedprocedure, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    foreach (var pram in parameters)
                    {
                        cmd.Parameters.AddWithValue(pram.ParameterName, pram.Value);
                    }

                    if (con.State != ConnectionState.Open)
                        con.Open();

                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        dt.Load(sdr);
                    }
                }
            }
            return dt;
        }
    }
}
