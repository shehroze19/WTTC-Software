﻿using MememberShipLoggingSystem.General;
using MememberShipLoggingSystem.Screens.Template;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MememberShipLoggingSystem.Screens
{
    public partial class LoginScreen : TemplateForm
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsFormValid())
                {
                    using (SqlConnection con = new SqlConnection(AppConnection.GetConnectionString()))
                    {
                        using (SqlCommand cmd = new SqlCommand("usp_UsersVerifyLoginDetails", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@UserName", UserNameTextBox.Text.Trim());
                            cmd.Parameters.AddWithValue("@Password", SecureData.EncryptData(PasswordTextBox.Text.Trim()));
                            if (con.State != ConnectionState.Open)
                                con.Open();
                            DataTable dtUsers = new DataTable();
                            SqlDataReader sdr = cmd.ExecuteReader();
                            if (sdr.HasRows)
                            {
                                dtUsers.Load(sdr);
                                DataRow userRow = dtUsers.Rows[0];
                                LoggedInUser.UserName = userRow["UserName"].ToString();
                                LoggedInUser.RoleId = Convert.ToInt32(userRow["RoleId"]);
                                this.Hide();
                                DashboardScreen dashboard = new DashboardScreen();
                                dashboard.Show();
                            }
                            else
                            {
                                MessageBox.Show("UserName or Password is Incorrect", "Authentication Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }


                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private bool IsFormValid()
        {
            if (UserNameTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("UserName is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                UserNameTextBox.Focus();
                return false;
            }
            if (PasswordTextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Password is Required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                PasswordTextBox.Focus();
                return false;
            }
            return true;
        }
    }
}
